﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OlympicWeb.Models
{
    public class AppManager : IAppManager
    {

        public List<Post>[] getPosts()
        { 
            Post p = new Post { PostId = 12, Content = "hello", Likes = 3 };
            List<Post>[] posts = new List<Post>[10];
            posts[0].Add(p);
            return posts;
        }
    }
}
